#include "marilynnp.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    printf("==================================================\n");
    printf(" libmarilynnp: LWE Cryptographic Noise Stress Test\n");
    printf("==================================================\n\n");

    size_t N = 1000;
    adelic_manifold_t manifold;
    marilyn_manifold_init(&manifold, N);

    /* The underlying 'Secret' or Invariant we want to extract */
    uint64_t true_secret = 0x0F0F0F0F0F0F0F0FULL;

    /* * Simulating Learning With Errors (LWE):
     * We create a temporal window (T = 4) where each snapshot contains
     * the true secret heavily distorted by random cryptographic noise.
     */
    size_t T = 4;
    uint64_t *noisy_window = malloc(T * sizeof(uint64_t));
    
    srand(time(NULL));
    printf("[*] Generating noisy temporal window (T = %zu)...\n", T);
    for (size_t i = 0; i < T; i++) {
        /* Generate a random 64-bit noise vector */
        uint64_t noise = ((uint64_t)rand() << 32) | rand();
        
        /* Inject the error into the secret (simulating b = As + e) */
        noisy_window[i] = true_secret ^ noise;
        
        printf("    Snapshot %zu: 0x%016llX (Noise injected)\n", i, (unsigned long long)noisy_window[i]);
    }

    printf("\n[*] Ingesting temporal window into the 2-adic manifold...\n");
    marilyn_manifold_ingest_temporal(&manifold, noisy_window, T);

    printf("[*] Executing Marilyn Fold to isolate the MSB-Prefix invariant...\n");
    if (marilyn_fold_execute(&manifold) != 0) {
        fprintf(stderr, "[!] Fold Execution Failed under stress.\n");
        free(noisy_window);
        marilyn_manifold_clear(&manifold);
        return 1;
    }
    printf("[+] Manifold folded. Noise stripped. Prefix isolated.\n\n");

    printf("[*] Initiating O(N) Grandparent Sentinel Audit on Dimension %zu...\n", N);
    sentinel_node_t *audit_nodes = malloc(N * sizeof(sentinel_node_t));
    
    int is_valid = sentinel_audit_verify(&manifold, audit_nodes);

    if (is_valid) {
        printf("[SUCCESS] Invariant held firm against cryptographic noise.\n");
        printf("[SUCCESS] LWE structural integrity bypassed in linear time.\n");
    } else {
        printf("[RESULT] Destructive interference detected. Invariant collapsed under noise.\n");
    }

    free(audit_nodes);
    free(noisy_window);
    marilyn_manifold_clear(&manifold);
    
    return 0;
}