#include "marilynnp.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void run_ceiling_test(size_t N) {
    adelic_manifold_t manifold;
    marilyn_manifold_init(&manifold, N);

    /* Generate a synthetic valid topological state for testing throughput */
    uint64_t synthetic_state = 0xAAAAAAAAAAAAAAAAULL; 
    uint64_t temporal_window[3] = { synthetic_state, synthetic_state, synthetic_state };
    
    marilyn_manifold_ingest_temporal(&manifold, temporal_window, 3);

    /* Measure Marilyn Fold Execution Time */
    clock_t start_fold = clock();
    marilyn_fold_execute(&manifold);
    clock_t end_fold = clock();
    double fold_time = ((double)(end_fold - start_fold)) / CLOCKS_PER_SEC;

    /* Measure O(N) Grandparent Audit Time */
    sentinel_node_t *audit_nodes = malloc(N * sizeof(sentinel_node_t));
    if (!audit_nodes) {
        printf("Memory allocation failed for N=%zu\n", N);
        return;
    }

    clock_t start_audit = clock();
    int is_valid = sentinel_audit_verify(&manifold, audit_nodes);
    clock_t end_audit = clock();
    double audit_time = ((double)(end_audit - start_audit)) / CLOCKS_PER_SEC;

    printf("N = %-8zu | Fold Time: %.6f s | Audit Time: %.6f s | Result: %s\n", 
           N, fold_time, audit_time, is_valid ? "PASS" : "FAIL");

    free(audit_nodes);
    marilyn_manifold_clear(&manifold);
}

int main() {
    printf("==================================================\n");
    printf(" libmarilynnp: O(N) Complexity Ceiling Benchmark\n");
    printf("==================================================\n\n");
    printf("A traditional O(N!) algorithm fails around N=20.\n");
    printf("Executing deterministic linear scale...\n\n");

    /* Scaling N up to test the ceiling */
    size_t test_sizes[] = {10, 100, 1000, 10000, 100000, 1000000};
    int num_tests = sizeof(test_sizes) / sizeof(test_sizes[0]);

    for (int i = 0; i < num_tests; i++) {
        run_ceiling_test(test_sizes[i]);
    }

    printf("\n[SUCCESS] Ceiling test completed.\n");
    return 0;
}