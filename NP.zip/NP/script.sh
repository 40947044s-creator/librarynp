# Compile the Marilyn Fold engine (requires AVX2 intrinsics)
clang -O3 -mavx2 -Wall -Wextra -I./include -c src/marilyn_fold.c -o build/marilyn_fold.o

# Compile the Adelic Manifold and Sentinel logic
clang -O3 -mavx2 -Wall -Wextra -I./include -c src/adelic_manifold.c -o build/adelic_manifold.o
clang -O3 -mavx2 -Wall -Wextra -I./include -c src/sentinel_audit.c -o build/sentinel_audit.o

clang -shared -o build/libmarilynnp.so build/marilyn_fold.o build/adelic_manifold.o build/sentinel_audit.o -lgmp

# Compile the Hamiltonian Path test
clang -O3 -mavx2 -I./include tests/test_hamiltonian.c build/libmarilynnp.so -lgmp -o build/test_hamiltonian

# Run the compiled test
./build/test_hamiltonian