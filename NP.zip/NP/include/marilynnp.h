#ifndef MARILYNNP_H
#define MARILYNNP_H

#include <stdint.h>
#include <stddef.h>
#include <gmp.h>

/* * Hardware Intrinsics
 * The blueprint relies heavily on SIMD for parallel O(1) bitwise operations.
 * This includes AVX2 for x86_64 architectures.
 */
#if defined(__AVX2__)
#include <immintrin.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @struct adelic_manifold_t
 * @brief Represents the 2-adic computational space.
 * * Instead of traditional adjacency matrices, the blueprint dictates 
 * mapping topological problems into bitstream manifolds. We use GMP 
 * (GNU Multiple Precision) to handle the arbitrarily large bit topologies.
 */
typedef struct {
    mpz_t topology_state;    /* The current global state of the graph/problem */
    size_t dimension_size;   /* N - the size of the input problem */
    int is_msb_isolated;     /* Boolean flag indicating MSB-prefix stability */
} adelic_manifold_t;

/**
 * @struct sentinel_node_t
 * @brief Represents a state node for the Grandparent Sentinel audit.
 * * Used to track the deterministic linear sequence of arithmetic 
 * residue resolutions, moving away from probabilistic search.
 */
typedef struct {
    uint64_t current_residue;
    uint64_t grandparent_residue;
    int is_valid_transition;
} sentinel_node_t;

/* =========================================================================
 * CORE API: Initialization & Memory Management
 * ========================================================================= */

/**
 * Initialize an Adelic manifold for a given problem size (N).
 */
void marilyn_manifold_init(adelic_manifold_t *manifold, size_t n);

/**
 * Free resources associated with the manifold.
 */
void marilyn_manifold_clear(adelic_manifold_t *manifold);

/**
 * Loads a sequence of cryptographic parameter snapshots into the 2-adic manifold.
 * Moving from a single-snapshot observation to a temporal window (T >= 2) 
 * resolves non-identifiability.
 */
void marilyn_manifold_ingest_temporal(adelic_manifold_t *manifold, const uint64_t *snapshots, size_t t_frames);

/* =========================================================================
 * CORE API: The Marilyn Fold
 * ========================================================================= */

/**
 * Executes the "Marilyn Fold" operation.
 * According to the blueprint, this collapses branching logic into 
 * a single sequence of carry-free logic (XOR Resonance).
 * * @param manifold The mathematical space being folded.
 * @return 0 on success, non-zero on failure.
 */
int marilyn_fold_execute(adelic_manifold_t *manifold);

/* =========================================================================
 * CORE API: The Grandparent Sentinel Framework
 * ========================================================================= */

/**
 * Performs a deterministic audit in O(N) time.
 * Verifies if the collapsed state yields a valid invariant (e.g., Hamiltonian Path).
 * * @param manifold The folded 2-adic space.
 * @param audit_nodes Array of tracking nodes for the sequence.
 * @return 1 if invariant found (True), 0 otherwise (False).
 */
int sentinel_audit_verify(const adelic_manifold_t *manifold, sentinel_node_t *audit_nodes);

#ifdef __cplusplus
}
#endif

#endif /* MARILYNNP_H */