#include "marilynnp.h"
#include <stdlib.h>
#include <stdio.h>

/* =========================================================================
 * CORE API: Initialization & Memory Management
 * ========================================================================= */

void marilyn_manifold_init(adelic_manifold_t *manifold, size_t n) {
    if (manifold == NULL) {
        return;
    }

    /* * mpz_init initializes the arbitrary-precision integer. 
     * For highly optimized O(1) bitwise operations later, you might 
     * switch this to mpz_init2(manifold->topology_state, expected_bits) 
     * to pre-allocate exact memory and prevent reallocation overhead.
     */
    mpz_init(manifold->topology_state);
    
    manifold->dimension_size = n;
    
    /* The manifold begins in an uncollapsed state */
    manifold->is_msb_isolated = 0; 
}

void marilyn_manifold_clear(adelic_manifold_t *manifold) {
    if (manifold == NULL) {
        return;
    }

    /* Free the GMP memory to prevent memory leaks */
    mpz_clear(manifold->topology_state);
    
    manifold->dimension_size = 0;
    manifold->is_msb_isolated = 0;
}

/* =========================================================================
 * MANIFOLD INGESTION: Temporal Reduction 
 * ========================================================================= */

/**
 * Loads a sequence of cryptographic parameter snapshots into the 2-adic manifold.
 * Moving from a single-snapshot observation to a temporal window (T >= 2) 
 * resolves non-identifiability prior to executing the Marilyn Fold.
 * * Note: Add `void marilyn_manifold_ingest_temporal(adelic_manifold_t *manifold, const uint64_t *snapshots, size_t t_frames);` to your marilynnp.h file.
 */
void marilyn_manifold_ingest_temporal(adelic_manifold_t *manifold, const uint64_t *snapshots, size_t t_frames) {
    if (manifold == NULL || snapshots == NULL) {
        return;
    }

    if (t_frames < 2) {
        fprintf(stderr, "Manifold Error: Temporal window requires T >= 2 to resolve non-identifiability.\n");
        return;
    }

    mpz_set_ui(manifold->topology_state, 0);

    /* * Pack the temporal snapshots sequentially into the large GMP integer.
     * This constructs the foundational 2-adic bitstream.
     */
    for (size_t i = 0; i < t_frames; i++) {
        mpz_t temp;
        mpz_init_set_ui(temp, snapshots[i]);
        
        /* Shift the existing state left by 64 bits to make room for the new frame */
        mpz_mul_2exp(manifold->topology_state, manifold->topology_state, 64);
        
        /* Bitwise OR the new snapshot into the lowest 64 bits */
        mpz_ior(manifold->topology_state, manifold->topology_state, temp);
        
        mpz_clear(temp);
    }
}