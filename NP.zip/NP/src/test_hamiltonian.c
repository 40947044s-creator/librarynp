#include "marilynnp.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("==================================================\n");
    printf(" libmarilynnp: Hamiltonian Path Grandparent Audit \n");
    printf("==================================================\n\n");

    size_t N = 5;
    adelic_manifold_t manifold;
    
    printf("[*] Initializing Adelic Manifold for Dimension N = %zu...\n", N);
    marilyn_manifold_init(&manifold, N);

    /* * TEST CASE: 5-Node Hamiltonian Graph
     * We encode the 5x5 adjacency matrix into a packed 64-bit hexadecimal state
     * to be mapped into the GMP topology.
     */
    uint64_t graph_state = 0x0E151B120CULL; 

    /* * Ingesting the graph state over a temporal window (T = 3).
     * Bypassing single-snapshot observations guarantees identifiability 
     * in the 2-adic bitstream prior to the XOR resonance fold.
     */
    uint64_t temporal_window[3] = { graph_state, graph_state, graph_state };
    
    printf("[*] Ingesting temporal window (T = 3) to resolve non-identifiability...\n");
    marilyn_manifold_ingest_temporal(&manifold, temporal_window, 3);

    printf("[*] Executing Marilyn Fold (Hardware SIMD XOR Resonance)...\n");
    if (marilyn_fold_execute(&manifold) != 0) {
        fprintf(stderr, "[!] Fold Execution Failed.\n");
        marilyn_manifold_clear(&manifold);
        return 1;
    }
    printf("[+] Manifold folded successfully. MSB-Prefix isolated.\n\n");

    printf("[*] Initiating O(N) Grandparent Sentinel Audit...\n");
    sentinel_node_t audit_nodes[N];
    
    int is_hamiltonian = sentinel_audit_verify(&manifold, audit_nodes);

    printf("--- Audit Trace ---\n");
    for (size_t i = 0; i < N; i++) {
        printf("Node [%zu]: Residue = 0x%016llX | Grandparent = 0x%016llX | Valid = %s\n",
               i,
               (unsigned long long)audit_nodes[i].current_residue,
               (unsigned long long)audit_nodes[i].grandparent_residue,
               audit_nodes[i].is_valid_transition ? "YES" : "NO");
    }
    printf("-------------------\n\n");

    if (is_hamiltonian) {
        printf("[SUCCESS] Arithmetic invariant confirmed. Hamiltonian Path exists!\n");
    } else {
        printf("[RESULT] Invariant broken. No Hamiltonian Path found.\n");
    }

    marilyn_manifold_clear(&manifold);
    return 0;
}